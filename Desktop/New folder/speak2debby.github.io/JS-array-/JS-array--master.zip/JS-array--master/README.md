# JS-array-
a simple JS code
